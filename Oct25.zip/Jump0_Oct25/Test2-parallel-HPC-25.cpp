// REMEMBER TO SET THE MODE, SWITCH TIME etc. 
// In this code, I am going to build on top of the August4_2023/Test1B.cpp
// I am going to see which step size is the most optimum first. 
// Then I am going to see if allowing bigger jumps in between helps at all. 

// In addition, I have allowed for switching between an exploration mode and a safety mode. 
#include <iostream>
#include <fstream>
#include <vector>
#include <random>
#include <chrono>
#include <cmath>
#include </home/harshjain/eigen3/Eigen/Dense>
#include </home/harshjain/eigen3/Eigen/Sparse>
//position of the target, given (50,50) is starting location of walker
// structure to represent the state of the walker
#include <omp.h> // Include the OpenMP header

#include <cstdlib> // for std::atoi

struct Walker {
    double x, y;
};
struct Target {
    double x,y;
};

double N=10000;  //lattice size
int JumpExtra = 0;
int switchTime; // Declared as a global variable whose value is set in main. 
const double a = 2.0; // target size
Target t = {N/2+10,N/2}; // target location
// number of simulations
const int numSimulations = 10000; //number of simulations
const int maxSteps  = 100000;
double beta; // Positive is repulsive and super-diffusive

double distanceToTarget(Walker w, Target t) {
    double dx = w.x - t.x;
    double dy = w.y - t.y;
    return std::sqrt(dx * dx + dy * dy);
}

//Prepare random number generation
std::random_device rd;
std::mt19937 gen(rd());
std::uniform_real_distribution<> uniformDist(0, 1);

Walker stepDir(Walker w, Eigen::Matrix3d G_Weights, int modeJump) {
    Eigen::Matrix3d funcWeights;
    float beta;
    // replace w by e^[beta*w] in the weight matrix.
    if (modeJump==0){
    double beta = 1; //repulsive
    funcWeights = G_Weights.unaryExpr([beta](double x) { return std::exp(-1* beta*x); });//beta=1 repulsive
    }
    else{
    double beta = -1; // attractive
    funcWeights = G_Weights.unaryExpr([beta](double x) {
            return std::exp(-1*beta*x); 
});
    }
    // a,b,c,d,e,f,g,h,i 9 states and 9 weights    
    std::vector<int> directions = {-1, 0, 1};
    std::vector<double> weightsList;
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            weightsList.push_back(funcWeights(i,j));

    // From the 3x3 matrix, I explicitly set the weight of inaccessible states (itself and diagonal) to zero. 
    weightsList[0] = weightsList[2] = weightsList[4] = weightsList[6] = weightsList[8] = 0.0;

    // Generate a distribution based on the weights
    std::discrete_distribution<> dist(weightsList.begin(), weightsList.end());

    // Generate a random index
    int randomIndex = dist(gen);

    // Calculate new coordinates
    int dirX = randomIndex / 3 - 1, dirY = randomIndex % 3 - 1;
    //   std::cout << "dirX: " << dirX << ", dirY: " << dirY << '\n';
    // Step size is chosen to be 1. 
    double stepX =1;
    double stepY =1;
    
    double walkerXOut = w.x + stepX*dirX;
    double walkerYOut = w.y + stepY*dirY;

    Walker walkerOut ={walkerXOut,walkerYOut};

    return walkerOut;
}

Walker jumpCalculate(Walker wIn, int modeJump,const Eigen::SparseMatrix<double>& G) { //walkerIn and Walker updated Out.
    int startX = (int) wIn.x;
    int startY = (int) wIn.y;

    Eigen::Matrix3d G_Weights;
 
    for(int i=0; i<3; ++i) {
    for(int j=0; j<3; ++j) {

        int XX = startX-1+i; 
        int YY = startY-1+j; 
        if (XX<0){
            XX+=N;
        }
        if (XX>(N-1)){
            XX-=N;
        }if (YY<0){
            YY+=N;//-JumpExtra
        }if (YY>(N-1)){
            YY-=N;
        }
        G_Weights(i,j) = (float)G.coeff(XX,YY);
    }
    }
    Walker walkerOut = stepDir(wIn, G_Weights, modeJump);
    //std::cout << "Matrix:\n" << G_Weights << std::endl;
    
    // std::cout<< startX<<std::endl;
    // Now, we pass the G_Weights and position to 

    // Update G matrix
    return walkerOut;
}

// Function to write sparse matrix to text file
void writeSparseTxt(const Eigen::SparseMatrix<double>& G, int simulationNumber) {
    std::string filename = "Gsim" + std::to_string(simulationNumber) + ".txt";
    std::ofstream out(filename);
    for (int k=0; k < G.outerSize(); ++k) {
        for (Eigen::SparseMatrix<double>::InnerIterator it(G,k); it; ++it) {
            out << it.row() << " " << it.col() << " " << it.value() << "\n";
        }
    }
    out.close();
}

int simulate(int ii) {
    int threadId = omp_get_thread_num(); // Get the thread number
    std::cout << "Thread " << threadId << " is running simulation " << ii << std::endl;

    // Rest of your simulation code...
        int modeJump=1; // Select the mode Beta-1H1

    // maximum steps for each simulation
        Walker w = {N/2,N/2};
        Eigen::SparseMatrix<double> G(N,N);  // initialize a 100x100 sparse matrix


        int step = 0;
        // run this simulation until the walker reaches the target or until maximum steps
    

    
        while (distanceToTarget(w, t) > a && step < maxSteps) {
            int startX = w.x/1;
            int startY = w.y/1;

            if ( (step % switchTime) ==0 ){
                modeJump=1-modeJump; // flip the mode of jumping
                std::cout << "Mode: " << modeJump << " Step:"<< step<< std::endl;

            }
            w = jumpCalculate(w,modeJump,G); // Add the jump by one step in some direction. 
            //Boundary Conditions (Compact)
            if (w.x<0+JumpExtra){
                w.x+= (float) N-2*JumpExtra;
            }
            if (w.y<0+JumpExtra){
                w.y+=(float) N-2*JumpExtra;
            }
            if (w.y>N-JumpExtra){
                w.y-=(float) N-2*JumpExtra;
            }
            if(w.x>N-JumpExtra){
                w.x-=(float) N-2*JumpExtra;
            }
            int outX=w.x/1;
            int outY=w.y/1;
           
            if (outX==startX && outY==startY){
                //Do nothing
            } else {
                // We introduce a step size larger than 1. JumpSize

                int dX = outX-startX;
                int dY = outY-startY;
                G.coeffRef(outX,outY) += 1;
                for (int i=0; i<JumpExtra; ++i){
                    w.x  += (float) dX;
                    w.y  += (float) dY;
                    outX += dX;
                    outY += dY;
                    G.coeffRef(outX,outY) += 1;
                    if (distanceToTarget(w,t)<a){
                        break;
                    }
                }
            }
            ++step;
	}
    // Print out which simulation we just ran
    // std::cout << "Finished running simulation " << (i+1) << std::endl;
       if ((ii+1) % 1 == 0) {
        std::cout << "Finished running simulation " << (ii+1) << std::endl;
        }
    return step;
}

int main(int argc, char *argv[]){


    if (argc < 2) {
	std::cerr << "Error: Missing argument for switchTime." << std::endl;
	return 1;
    }

    switchTime = std::atoi(argv[1]);
    std::cout << "switchTime is set to: " << switchTime << std::endl;

    std::vector<int> firstPassageTimes(numSimulations);

   #pragma omp parallel for 
    // run simulations
    for (int ii = 0; ii < numSimulations; ++ii) {
    int step = simulate(ii); // Pass the timesList vector by reference
    // maximum steps for each simulation 
    firstPassageTimes[ii]=step;

    }

    // Create the filename by concatenating the values
    std::string filename = "DataOut/first_passage_times_SwitchTime" + std::to_string(switchTime) + "Jump" + std::to_string(JumpExtra) + "Test2.txt";
    //
    // Open the file with the generated filename
    std::ofstream outFile(filename);

    // std::ofstream outFile("DataOut/first_passage_times_SwitchTime100Jump0Test2.txt");
    for (int time : firstPassageTimes) {
        outFile << time << std::endl;
    }
    outFile.close();

return 0;

}

