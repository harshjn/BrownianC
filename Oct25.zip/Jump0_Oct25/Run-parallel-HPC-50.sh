
#!/bin/bash

# Set the name of the output executable
executable="test_output_location"

# Set the name of the log file
log_file="Out1/output_log.txt"

module load compilers/gcc/13.0.0


# Compile the C++ program and redirect stdout and stderr to the log file
g++ -fopenmp -o "$executable" Jump0_Oct25/Test2-parallel-HPC-25.cpp > "$log_file" 2>&1

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "Compilation successful."
   

    for switchTime in $(seq 2000 100 10000); do
    	echo "Running the program with SwitchTime=$switchTime ..."
 
    	# Run the compiled program and append the output to the log file
    	./"$executable" $switchTime >> "$log_file" 2>&1

    
    	# Check the exit status of the program
    	if [ $? -eq 0 ]; then
        	echo "Program executed successfully with switchTime=$switchTime ."
    	else
        	echo "Error: Program execution failed with switchTime=$switchTime ."
    	fi
    done
else
    echo "Error: Compilation failed."
fi

